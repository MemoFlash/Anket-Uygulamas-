package com.example.anketuygulamasi;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class Anket4 extends AppCompatActivity {

    Button butonileri4;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.anket4);

        butonileri4 = (Button)findViewById(R.id.butonileri4);
        butonileri4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Anket4.this,Anket5.class);
                startActivity(i);
            }
        });

    }
}