package com.example.anketuygulamasi;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class Anket3 extends AppCompatActivity {

    Button butonileri3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.anket3);
        butonileri3 = (Button)findViewById(R.id.butonileri3);
        butonileri3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Anket3.this,Anket4.class);
                startActivity(i);
            }
        });
    }
}