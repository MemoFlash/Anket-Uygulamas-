package com.example.anketuygulamasi;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class Anket2 extends AppCompatActivity {

    Button butonileri2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.anket2);

        butonileri2 = (Button)findViewById(R.id.butonileri2);
        butonileri2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Anket2.this,Anket3.class);
                startActivity(i);
            }
        });
    }
}